const btn = document.getElementById("btn");
const fileInput = document.getElementById("fileInput");
const output = document.getElementById("output");
const download = document.getElementById("download");
const sizeSelect = document.getElementById("sizeSelect");
const widthInput = document.getElementById("widthInput");
const heightInput = document.getElementById("heightInput");
const originalWidth = document.getElementById("originalWidth");
const originalHeight = document.getElementById("originalHeight");
const fileSize = document.getElementById("fileSize");

fileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file) {
    if (!file.type.match('image/jpeg')) {
      alert('Please upload a JPEG or JPG file.');
      fileInput.value = ''; // Clear the file input
      return;
    }

    const filename = URL.createObjectURL(file);
    output.setAttribute('src', filename);

    const img = new Image();
    img.onload = () => {
      originalWidth.textContent = img.width;
      originalHeight.textContent = img.height;
      fileSize.textContent = (file.size / 1024).toFixed(2) + ' KB';
    };
    img.src = filename;
  }
});

sizeSelect.addEventListener("change", (e) => {
  if (e.target.value === "custom") {
    document.getElementById("customDimensions").style.display = "block";
  } else {
    document.getElementById("customDimensions").style.display = "none";
  }
});

btn.addEventListener("click", (event) => {
  event.preventDefault(); // Prevent default form submission
  const file = fileInput.files[0];
  const size = sizeSelect.value;

  if (file) {
    if (!file.type.match('image/jpeg')) {
      alert('Please upload a JPEG or JPG file.');
      return;
    }

    const formData = new FormData();
    formData.append("imageInput", file);
    formData.append("size", size);

    if (size === "custom") {
      const width = widthInput.value;
      const height = heightInput.value;

      if (!width || !height) {
        alert('Please provide both width and height for custom size.');
        return;
      }

      formData.append("width", width);
      formData.append("height", height);
    }

    fetch("/upload", {
      method: "POST",
      body: formData,
    })
    .then(response => response.json())
    .then(data => {
      if (data.data) {
        const link = document.createElement('a');
        link.href = data.data;
        link.download = 'optimized_image.jpg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        console.error("Error:", data.error);
      }
    })
    .catch(err => console.log("Error:", err));
  }
});
