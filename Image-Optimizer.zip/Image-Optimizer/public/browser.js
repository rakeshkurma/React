const btn = document.getElementById("btn");
const fileInput = document.getElementById("fileInput");
const output = document.getElementById("output");
const download = document.getElementById("download");

fileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file) {
    if (!file.type.match('image/jpeg')) {
      alert('Please upload a JPEG or JPG file.');
      fileInput.value = ''; // Clear the file input
      return;
    }
    const filename = URL.createObjectURL(file);
    output.setAttribute('src', filename);
  }
});

btn.addEventListener("click", (event) => {
  event.preventDefault(); // Prevent default form submission
  const file = fileInput.files[0];
  if (file) {
    if (!file.type.match('image/jpeg')) {
      alert('Please upload a JPEG or JPG file.');
      return;
    }

    const formData = new FormData();
    formData.append("imageInput", file);

    fetch("/upload", {
      method: "POST",
      body: formData,
    })
    .then(response => response.json())
    .then(data => {
      if (data.data) {
        output.setAttribute("src", data.data);
        download.setAttribute("href", data.data);
        download.setAttribute("download", "optimized_image.jpg");
      } else {
        console.error("Error:", data.error);
      }
    })
    .catch(err => console.log("Error:", err));
  }
});
