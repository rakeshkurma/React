const express = require("express");
const multer = require("multer");
const sharp = require("sharp");
const path = require("path");
const app = express();
const port = 4000;

// Serve static files
app.use(express.static(path.join(__dirname, "public")));

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Serve index.html to '/'
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.post("/upload", upload.single("imageInput"), (req, res) => {
  if (!req.file) {
    return res.status(400).send({ error: "No file uploaded" });
  }

  if (!req.file.mimetype === 'image/jpeg') {
    return res.status(400).send({ error: "Invalid file type. Please upload a JPEG or JPG file." });
  }

  const image = sharp(req.file.buffer);
  image
    .jpeg({ mozjpeg: true })
    .toBuffer()
    .then(data => {
      const base64Encoded = data.toString("base64");
      const url = `data:image/jpeg;base64,${base64Encoded}`;
      res.status(200).send({ data: url });
    })
    .catch(err => {
      console.error("Error processing image:", err);
      res.status(500).send({ error: "Failed to process image" });
    });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
